<?php 
    $grandtotal=0;
    $con=mysqli_connect("localhost","root","","account_esta");
    $invoice_id=$_GET["invoice_id"];

    $customer_id=$_GET["customer_id"];
    $customer_name_fetch=mysqli_query($con,"select * from customer_master where customer_id='".$customer_id."'");
    $customer_name_row=mysqli_fetch_assoc($customer_name_fetch);
    $customer_name=$customer_name_row["customer_name"];

    $customer_info=mysqli_query($con,"select * from customer_bill_history where invoice_id='".$invoice_id."'");
    
?>

<html>
<head>
<title>Bill Generation</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

<link rel="stylesheet" type="text/css" href="css/bill.css">
<!------ Include the above in your HEAD tag ---------->
</head>
<body>

<br>
<br>

  <table border="0" width="76%" align="center">
    <tr>
      <td width="50%">
        <table  style="margin-top: 0%">

          <tr>
            <td>Bill To:</td>
          </tr>

          <tr>
            <td><b><?php echo $customer_name; ?></b></td>
          </tr>
          
        </table>
      </td>
      <td>
        <table border="0" width="100%">
          <tr>
            <td><b>Invoice Number</b></td>
            <td><?php echo $invoice_id;?></td>
          </tr>
          <tr>
            <td><b>Invoice Date</b></td>
            <td>17/07/2019</td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
  <br>
 <div style="margin-top:60px;">   
<h3 style="margin-left:154px;" class="a">Products</h3>
 
<div class="shopping-cart" style="margin-left: 12%">
 
  <div class="column-labels">
    
    <label class="product-details">Product</label>
    <label class="product-price">Price</label>
    <label class="product-quantity">Quantity</label>
    <label class="product-removal">Remove</label>
    <label class="product-line-price" >Total</label>
  </div>
  
  
    <?php 
        while($rs=mysqli_fetch_assoc($customer_info))
        { ?>
<div class="product">
    <div class="product-details">
      <div class="product-title"><?php 
      
       $product_info=mysqli_query($con,"select product_name from product_master where product_id='".$rs["product_id"]."'");
       $product_name=mysqli_fetch_assoc($product_info);
       echo $product_name["product_name"];
      //echo $rs["product_id"]; ?></div>
      
    </div>
    <div class="product-price"><?php echo $rs["bill_product_price"]; ?></div>
    <div class="product-quantity" ><?php echo $rs["bill_product_qty"]; ?></div>

    <div class="product-line-price" style="margin-left:105px;"><?php echo $rs["product_total"]; ?></div>
</div>
       <?php
        $grandtotal=$grandtotal+$rs["product_total"];
    } ?>


  <div class="totals">
  	<div class="bb" style="width:80%;" align="center"></div>
  	<br>
    <div class="totals-item">
      <label>Subtotal</label>
      <div class="totals-value" id="cart-subtotal" style="margin-right: 20%; float: right;">
      <?php
        echo $grandtotal;
      ?>
      </div>
    </div>
    
    <div class="totals-item totals-item-total">
      <label>Grand Total</label>
      <div class="totals-value" id="cart-total" style="margin-right: 20%; float: right;">
      <?php
        echo $grandtotal;
      ?>
      </div>
    </div>
  </div>
   <div>
   </div>   
</div>
</div>

	
</div>
</body>
</html>
