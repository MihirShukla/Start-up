<?php
    include("sidebar.html");
?>
<html>
	<head>
    	<title>Add Customer</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	</head>
	<body>
		<div class="container">
        
        <!--nav bar-->
				<div class="row" style="margin-top:30px">
					<div class="col-lg-8 col-lg-offset-2">
						<ul class="nav nav-tabs">
						  <li id="contact-b" class="active"><a href="#contact">Add Customer</a></li>
						</ul>
					</div>
				</div>
				<br/>
				<br/>
                
				<div class="row">
					<div id="contact" class="col-lg-6 col-lg-offset-3">
						<form method="post">
						  
                          <div class="form-group">
							<label>Customer Name</label>
							<input type="text" name="customer_name" class="form-control" placeholder="customer name" required>
						  </div>
                          <div class="form-group">
							<label>City</label>
							<input type="text" name="city" class="form-control" placeholder="City" required>
						  </div>
                          <div class="form-group">
							<label>Mobile No.</label>
							<input type="number" name="mobile" class="form-control" placeholder="mobile number" required>
						  </div>
							<br>
						  <button style="width:100px;" type="submit" name="add-customer" class="btn btn-danger">ADD</button>
						
                        </form>
                        
            <!--form submition -->
						<?php
							if(isset($_POST["add-customer"]))
							{
								$con=mysqli_connect("localhost","root","","account_esta");
                                $addCustomer=mysqli_query($con,"insert into customer_master (customer_name,customer_city,customer_phone_no) values ('".$_POST["customer_name"]."','".$_POST["city"]."','".$_POST["mobile"]."')");
                                
                                if($addCustomer)
                                {
                                   header("location:billone.php");
                                }
                                else
                                {
                                    echo "customer not added successfully";
                                }
							}	
						?>
					</div>
				</div>
		</div>
	</body>
</html>