<?php
    include("sidebar.html");
?>

<html>

<head>
    <title>Bill Creation</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>

<body>
    <div class="container">

        <!--nav bar-->
        <div class="row" style="margin-top:30px">
            <div class="col-lg-8 col-lg-offset-2">
                <ul class="nav nav-tabs">
                    <li id="contact-b" class="active"><a href="">Bill Creation</a></li>
                </ul>
            </div>
        </div>
        <br/>
        <br/>

        
        <div class="row">
            <div id="contact" class="col-lg-6 col-lg-offset-3">
                    <form method="post" action="addcustomer.php">
                        <button type="submit" class="btn btn-success">Add New Customer</button>
                    </form>
        
                    <br>
    
                   <form method="post" action="billsecond.php">
                    <!-- <h3><u>Vendor Details</u></h3>
                        <br> -->
                        <div class="form-group">
                            <label><h3>Customer Name</h3></label>
                            <br>
                            <!--<input type="text" name="name" class="form-control" placeholder="Vendor Name" value="<?php// if(isset($_POST["done"])){echo $_POST["name"];}?>" required> -->
                            <?php 
                                
                                $con=mysqli_connect("localhost","root","","account_esta");
                                $customer=mysqli_query($con,"select * from customer_master");
                                        
                            ?>
                            <select class="form-control" name="customer_name">
                                <?php 
                                    while($rs=mysqli_fetch_assoc($customer))
                                    {
                                        ?><option class="form-control" value="<?php echo $rs["customer_name"]; ?>"><?php echo $rs["customer_name"]; ?></option>
                                <?php }
                                    ?>
                            </select> 
                        </div>
                    

                        <div class="form-group">
                            <label><h3>No. Of Items</h3></label>
                            <input type="number" id="number" name="number" class="form-control" placeholder="Items" value="<?php if(isset($_POST["done"])){echo $_POST["number"];}?>" required>
                        </div>
                          <br>              
                        <button style="width:150px;" type="submit" id="add-item" name="add-item" class="btn btn-danger">Add Items</button>

                    </form>
            </div>
        </div>
    </div>
</body>

</html>