<?php
    include("sidebar.html");
?>
<?php
    $server = "localhost";
    $username = "root";
    $link = mysqli_connect($server, $username, "");
    mysqli_select_db($link,"account_esta");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Custmer History</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<body>
<div class="container">
         
        <!--nav bar-->
				<div class="row" style="margin-top:30px">
					<div class="col-lg-8 col-lg-offset-2">
						<ul class="nav nav-tabs">
						  <li id="contact-b"><a href="#contact">Add Customer</a></li>
						</ul>
					</div>
				</div>
				<br/>
				<br/>
                
				<div class="row">
					<div id="contact" class="col-lg-6 col-lg-offset-3">
                        <form name="f" method="post">
                        <div class="form-group">
                            <select name="name" class="form-control">
                                <?php 
                                    $select = mysqli_query($link,"select * from customer_master");
                                    while ($row = mysqli_fetch_array($select)) {
                                ?>
                                <option value="<?php 
                                
                                if(isset($_POST["submit"]))
                                {
                                    echo $_POST["name"];    
                                }
                                else
                                {
                                    echo $row["customer_name"]; 
                                }
                                ?>"><?php 
                                
                                if(isset($_POST["submit"]))
                                {
                                    echo $_POST["name"];    
                                }
                                else
                                {
                                    echo $row["customer_name"]; 
                                }
                                
                                ?></option>
                                <?php 
                                    }
                                ?>
                            </select>
                        </div>
                            
                        <button type="submit" name="submit" class="btn btn-default">submit</button>
                        </form>
                       <?php if(isset($_POST["submit"]))
                       {
                           ?> 
                        <table border="1">
                                <tr>
                                <th>Product Name</td>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Total</th>
                                </tr>
                                <?php 
                                if(isset($_POST["submit"])){
                                    $name = $_POST["name"];
                                    $select = mysqli_query($link, "select customer_id from customer_master where customer_name='".$name."'");
                                    while($row = mysqli_fetch_array($select)){
                                        $id = $row["customer_id"];
                                    }
                                    $select = mysqli_query($link, "SELECT c.customer_id,p.product_name as pname,p.product_id,c.bill_product_qty as qty,c.bill_product_price as price,c.product_total as total,c.invoice_id as invoice FROM product_master as p , customer_bill_history as c WHERE c.customer_id='".$id."' and p.product_id in(SELECT c.product_id FROM customer_bill_history WHERE c.customer_id='".$id."')");
                                    while($row = mysqli_fetch_array($select)){
                                        $invoice = $row["invoice"];
                                ?>
                                <tr>
                                    <td><?php echo $row["pname"];?></td>
                                    <td><?php echo $row["qty"];?></td>
                                    <td><?php echo $row["price"];?></td>
                                    <td><?php echo $row["total"];?></td>
                                </tr>
                                <?php }?>
                                
                                <tr>
                                    <td colspan="2" align="center">Grand Total</td>
                                    <?php 
                                    $select = mysqli_query($link, "select invoice_grand_total from invoice_master where invoice_id ='".$invoice."'");
                                    while($row = mysqli_fetch_array($select)){
                                        $gt = $row["invoice_grand_total"];
                                    
                                    ?>
                                    <td colspan="2" align="center"><?php echo $gt;?></td>
                                    <?php }?>
                                </tr>
                                <?php 
                            
                                $select = mysqli_query($link, "select credit,debit from invoice_master where invoice_id='".$invoice."'");
                                while($row = mysqli_fetch_array($select)){
                                    $credit = $row["credit"];
                                    $debit = $row["debit"];
                                }}
                                ?>
                                <tr>
                                    <td colspan="2" align="center">Credit</td>
                                    <td colspan="2" align="center"><?php if(isset($credit)){echo $credit;}?></td>
                                </tr>
                                <tr>
                                    <td colspan="2" align="center">Debit</td>
                                    <td colspan="2" align="center"><?php if(isset($debit)){echo $debit;}?></td>
                                </tr>
                        </table>
                            
                            
                            
                        <form method="post" action="">    
                        Credit:<input type="text" name="credit">
                        
                        <input type="hidden" name="nm" value="<?php if(isset($_POST['submit'])){echo $name;}?>">
                        <input type="hidden" name="cc" value="<?php if(isset($credit)){echo $credit;}?>">
                        <input type="hidden" name="dd" value="<?php if(isset($debit)){echo $debit;}?>">
                        <input type="hidden" name="gt" value="<?php if(isset($gt)){echo $gt;}?>">
                        <input type="submit" name="update" value="update">
                        </form>
                        <?php 
                        
                            if(isset($_POST["update"])){
                                $name = $_POST["nm"];
                                $select = mysqli_query($link, "select customer_id from customer_master where customer_name='".$name."'");
                                while($row = mysqli_fetch_array($select)){
                                $id = $row["customer_id"];
                                }
                                $select = mysqli_query($link, "SELECT c.invoice_id as invoice FROM customer_bill_history as c WHERE c.customer_id='".$id."'");
                                while($row = mysqli_fetch_array($select)){
                                    $invoice = $row["invoice"];
                                }
                                $gt = $_POST["gt"];
                                $c = (int)$_POST["cc"]+(int)$_POST["credit"]; 
                                $d = (int)$gt - (int)$c;
                                
                            
                                mysqli_query($link, "update invoice_master set credit='".$c."',debit='".$d."' where invoice_id='".$invoice."'");
                            }
                        ?>
                                <?php 
                                mysqli_close($link);
                        }
              ?>
       	
                </div>
           </div>
        </div>
</body>
</html>